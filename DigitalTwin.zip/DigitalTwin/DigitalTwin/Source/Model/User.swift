//
//  User.swift
//  DigitalTwin
//
//  Created by Kanyanat Meejareon on 1/10/2563 BE.
//

import Foundation

class User: Codable{
    
    var name: String?
    var surname: String?
    var age: String?
    var gender: String?
    var licenseNo: String?
    var username: String?
    var password: String?
  
}
