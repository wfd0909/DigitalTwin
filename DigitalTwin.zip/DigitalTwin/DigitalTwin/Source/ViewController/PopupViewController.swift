//
//  PopupViewController.swift
//  DigitalTwin
//
//  Created by Kanyanat Meejareon on 29/10/2563 BE.
//

import UIKit

class PopupViewController: UIViewController {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var mobilitySpacesLabel: UILabel!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var latitudeLabel: UILabel!
    @IBOutlet weak var longtitudeLabel: UILabel!
    
    lazy var viewModel:PopupViewModel? = {
        return PopupViewModel()
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupDetail()
        
    }
    
    func setupDetail(){
        guard let viewModel = self.viewModel else {
            return
        }
        guard let parkingLocation = viewModel.parkingLocation else {
            return
        }
        nameLabel.text = parkingLocation.name
        addressLabel.text = "Address : "+parkingLocation.address!
        mobilitySpacesLabel.text = "Mobility Spaces : "+String(parkingLocation.mobilitySpaces!)
        typeLabel.text = "Type : "+parkingLocation.type!
        latitudeLabel.text = "Latitude : "+String(parkingLocation.latitude!)
        longtitudeLabel.text = "Longtitude : "+String(parkingLocation.longitude!)
    }
    
}
