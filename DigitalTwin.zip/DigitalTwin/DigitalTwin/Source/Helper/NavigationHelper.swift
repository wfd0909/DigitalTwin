//
//  NavigationHelper.swift
//  DigitalTwin
//
//  Created by Kanyanat Meejareon on 9/10/2563 BE.
//

import UIKit

class NavigationHelper: NSObject {

    public static func loadTabbar(storyboard : String, storyboardId : String) -> UITabBarController{
        var mainView: UIStoryboard!
        mainView = UIStoryboard(name: storyboard, bundle: nil)
        let tabbar : UITabBarController = mainView.instantiateViewController(withIdentifier: storyboardId) as! UITabBarController
        return tabbar
    }
    
    public static func loadController(storyboard : String, storyboardId : String) -> UIViewController{
        var mainView: UIStoryboard!
        mainView = UIStoryboard(name: storyboard, bundle: nil)
        let viewController : UIViewController = mainView.instantiateViewController(withIdentifier: storyboardId) 
        return viewController
    }
    
    
}

