//
//  LoginViewModel.swift
//  DigitalTwin
//
//  Created by Kanyanat Meejareon on 30/9/2563 BE.
//

import Foundation
import CodableFirebase


class LoginViewModel{
   
    var delegate: LoginViewModelDelegate!
    var userList: [User] = []
    var currentuser: User?
    var parkinglocationList: [ParkingLocation] = []
    
    func setup(){
        getUser()
        getParkingLocation()
    }
    
    func checkLogin(username: String, password: String) {
        if username.isEmpty || password.isEmpty{
            delegate.showMessageAlert(message: "please fill out this field")
        }
        if let user = userList.first(where: {$0.username == username}) {
            if password == user.password{
                self.currentuser = user
                
                delegate.showMainpage()
            }else{
                delegate.showMessageAlert(message: "incorrect password")
            }
        } else {
            delegate.showMessageAlert(message: "incorrect username")
        }
    }
    
    func getUser(){
        DBService.getUserDB { (userList) in
            self.userList = userList
        }
    }
    
    func getParkingLocation(){
        APIService.getParkingLocation{ (parkingLocationList) in
            self.parkinglocationList = parkingLocationList
        }
    }
}




