//
//  PersonalDetailViewController.swift
//  DigitalTwin
//
//  Created by Kanyanat Meejareon on 5/10/2563 BE.
//

import UIKit

class PersonalDetailViewController: UIViewController {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var usernameLabel: UILabel!
    @IBOutlet weak var sernameLabel: UILabel!
    @IBOutlet weak var licenseNoLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    
    lazy var viewModel:PersonalDetailViewModel? = {
        return PersonalDetailViewModel()
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        setPersonalDetail()
       
    }
    
    func setPersonalDetail(){
        guard let viewModel = self.viewModel else {
            return
        }
        guard let currentUser = viewModel.currentUser else {
            return
        }
        self.nameLabel.text = "Name : "+currentUser.name!
        self.usernameLabel.text = "Username : "+currentUser.username!
        self.sernameLabel.text = "Surname : "+currentUser.surname!
        self.licenseNoLabel.text = "LicenseNo : "+currentUser.licenseNo!
        self.ageLabel.text = "Age : "+currentUser.age!
        
    }

}
