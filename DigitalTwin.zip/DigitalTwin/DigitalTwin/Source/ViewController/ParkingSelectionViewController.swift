//
//  ParkingSelectionViewController.swift
//  DigitalTwin
//
//  Created by Kanyanat Meejareon on 5/10/2563 BE.
//

import UIKit

class ParkingSelectionViewController: UIViewController {
    
    lazy var viewModel:ParkingSelectionViewModel? = {
        return ParkingSelectionViewModel()
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
        super.viewWillAppear(animated)
    }

    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
        super.viewWillDisappear(animated)
    } 
    
    @IBAction func selectedParking(_ sender: Any) {
        guard let viewModel = self.viewModel else {
            return
        }

        UIViewController.goToDigitalTwin(parkinglocation: viewModel.parkingLocationList[0], src: self)
    }
    
    
}
