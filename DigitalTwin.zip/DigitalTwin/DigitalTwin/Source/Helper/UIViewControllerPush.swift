//
//  UIViewControllerPush.swift
//  DigitalTwin
//
//  Created by Kanyanat Meejareon on 9/10/2563 BE.
//

import UIKit

extension UIViewController{
    
    static func goToMainPage(currentUser: User, parkinglocationList: [ParkingLocation]){
        
        let mainTB = NavigationHelper.loadTabbar(storyboard: "MainPage", storyboardId: "MainTabbarController") as! MainTabbarController
        
        
        let personalDetailVC = mainTB.viewControllers?[1] as! PersonalDetailViewController
        let navigationVC = mainTB.viewControllers?[0] as! UINavigationController
        let parkingSelectionVC = navigationVC.viewControllers.first as! ParkingSelectionViewController
        
        guard let parkingSelectionVm = parkingSelectionVC.viewModel else {
            return
        }
        guard let personalDetailVm = personalDetailVC.viewModel else {
            return
        }
        parkingSelectionVm.parkingLocationList = parkinglocationList
        personalDetailVm.currentUser = currentUser
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.switchRootViewController(rootViewController: mainTB, animated: true, completion: nil)
        
    }
    
    static func goToDigitalTwin(parkinglocation: ParkingLocation, src: UIViewController){
        
        
        let parkingDigitalTwinVC = NavigationHelper.loadController(storyboard: "MainPage", storyboardId: "ParkingDigitalTwinViewController") as! ParkingDigitalTwinViewController
        
        
        guard let parkingDigitalTwinVm = parkingDigitalTwinVC.viewModel else {
            return
        }
        
        parkingDigitalTwinVm.parkingLocation = parkinglocation
        
        src.navigationController?.pushViewController(parkingDigitalTwinVC, animated: true)
        
    }

    static func goToPopup(parkinglocation: ParkingLocation, src: UIViewController){
    
    
        let popupVC = NavigationHelper.loadController(storyboard: "MainPage", storyboardId: "PopupViewController") as! PopupViewController
    
    
        guard let popupVm = popupVC.viewModel else {
            return
        }
    
        popupVm.parkingLocation = parkinglocation
    
        src.navigationController?.present(popupVC, animated: true)
        
    }
}
    
