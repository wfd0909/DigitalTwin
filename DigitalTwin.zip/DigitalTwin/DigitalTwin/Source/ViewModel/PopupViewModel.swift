//
//  PopupViewModel.swift
//  DigitalTwin
//
//  Created by Kanyanat Meejareon on 29/10/2563 BE.
//

import Foundation

class PopupViewModel{
    
    var parkingLocation: ParkingLocation?
    
}
