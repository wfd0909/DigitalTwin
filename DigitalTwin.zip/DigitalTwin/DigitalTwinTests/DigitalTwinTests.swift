//
//  DigitalTwinTests.swift
//  DigitalTwinTests
//
//  Created by Kanyanat Meejareon on 8/10/2563 BE.
//

import XCTest
@testable import DigitalTwin

class DigitalTwinTests: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    
    func testDB() throws {
        DBService.getUserDB { (userList) in
            XCTAssertTrue(userList.count != 0)
        }
    }

    func testAPI()throws {
        APIService.getParkingLocation{ (parkingLocationList) in
            XCTAssertTrue(parkingLocationList.count != 0)
        }
    }
    
    func testPerformanceApp() throws {
        //a performance test case.
        self.measure {
            
        }
    }

}
