//
//  APIService.swift
//  DigitalTwin
//
//  Created by Kanyanat Meejareon on 11/10/2563 BE.
//

import Foundation
import Alamofire
import CodableFirebase

class APIService{
    
    static func getParkingLocation( completion : @escaping([ParkingLocation]) -> Void){
        let url = AppDefine.GET_PARKING_LOGATION_API
        let headers: HTTPHeaders = [AppDefine.AUT_KEY: AppDefine.AUT_VAL]
        var parkinglocationList: [ParkingLocation] = []

        Alamofire.request(url,method: .get, headers: headers)
          .responseJSON { response in
            
            guard let result = response.result.value else {
                return
            }
            let data = result as! NSDictionary
            if data["status"] as! String == "OK"{
                do {
                    guard let response = data["response"] else {
                        return
                    }
                    parkinglocationList = try FirebaseDecoder().decode([ParkingLocation].self, from: response )
                    completion(parkinglocationList)
                } catch let error {
                    print(error)
                    completion(parkinglocationList)
                }
            }else{
                guard let response = data["response"] else {
                    return
                }
                print(response)
                completion(parkinglocationList)
            }
        }
    }
}
