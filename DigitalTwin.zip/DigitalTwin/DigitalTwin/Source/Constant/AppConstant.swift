//
//  AppConstant.swift
//  DigitalTwin
//
//  Created by Kanyanat Meejareon on 8/10/2563 BE.
//

import Foundation

class AppDefine: NSObject {
    
    
    //Constant for API
    static let GET_PARKING_LOGATION_API = "https://api.at.govt.nz/v2/locations/parkinglocations"
    static let AUT_KEY = "Ocp-Apim-Subscription-Key"
    static let AUT_VAL = "411ab401b77e47c0b4e21b9f2582226e"
    
}
