//
//  DBService.swift
//  DigitalTwin
//
//  Created by Kanyanat Meejareon on 11/10/2563 BE.
//

import Foundation
import CodableFirebase
import FirebaseDatabase

class DBService{

    static var database = Database.database().reference()

    static func getUserDB(completion : @escaping([User]) -> Void){
        
        var userList: [User] = []

        database.child("Users").observeSingleEvent(of: .value, with: { snapshot in
            guard let value = snapshot.value as? NSArray else {
                return
            }
            do {
                userList = try FirebaseDecoder().decode([User].self, from: value)
                completion(userList)
            } catch let error {
                print(error)
            }
          }) { error in
            print(error.localizedDescription)
            completion(userList)
        }
    }
}
