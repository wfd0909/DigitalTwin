//
//  MainTabbarController.swift
//  DigitalTwin
//
//  Created by Kanyanat Meejareon on 9/10/2563 BE.
//

import UIKit

class MainTabbarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }


}
