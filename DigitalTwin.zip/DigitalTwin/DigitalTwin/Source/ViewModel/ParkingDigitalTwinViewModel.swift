//
//  ParkingDigitalTwinViewModel.swift
//  DigitalTwin
//
//  Created by Kanyanat Meejareon on 5/10/2563 BE.
//

import Foundation

class ParkingDigitalTwinViewModel{
    
    var parkingLocation: ParkingLocation?
    
    func setupText() -> String{
        guard let parkingLocation = self.parkingLocation else {
            return ""
        }
        guard let mobilitySpaces = parkingLocation.mobilitySpaces else {
            return ""
        }
        return "Mobility Spaces : "+String(mobilitySpaces)
    }
    
}

