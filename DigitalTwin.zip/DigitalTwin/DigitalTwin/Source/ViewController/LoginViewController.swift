//
//  ViewController.swift
//  DigitalTwin
//
//  Created by Kanyanat Meejareon on 29/9/2563 BE.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!

    lazy var viewModel:LoginViewModel? = {
        return LoginViewModel()
    }()
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        guard let viewModel = self.viewModel else {
            return
        }
        viewModel.delegate = self
        viewModel.setup()
    }

    @IBAction func didSigninButton(_ sender: Any) {
        
        guard let viewModel = self.viewModel else {
            return
        }
        guard let username = usernameTextField.text else {
            return
        }
        guard let password = passwordTextField.text else {
            return
        }
        
        viewModel.checkLogin(username: username, password: password)
    }
    
    
}

extension LoginViewController: LoginViewModelDelegate{
    func showMainpage() {
        
        guard let viewModel = self.viewModel else {
            return
        }
        guard let currentUser = viewModel.currentuser else {
            return
        }
        let parkinglocationList = viewModel.parkinglocationList
        
        UIViewController.goToMainPage(currentUser: currentUser, parkinglocationList: parkinglocationList)
        
    }
    
    func showMessageAlert(message: String) {
        let alert = UIAlertController(title: "Error message", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    


}
