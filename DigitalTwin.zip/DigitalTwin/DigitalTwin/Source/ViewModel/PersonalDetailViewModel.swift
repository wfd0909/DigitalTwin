//
//  PersonalDetailViewModel.swift
//  DigitalTwin
//
//  Created by Kanyanat Meejareon on 5/10/2563 BE.
//

import Foundation

class PersonalDetailViewModel{
    
    var currentUser: User?
    
    func printuser(){
        print(self.currentUser)
    }
    
}
