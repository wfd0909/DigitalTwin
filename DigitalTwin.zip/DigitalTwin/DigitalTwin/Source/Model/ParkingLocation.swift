//
//  ParkingLocation.swift
//  DigitalTwin
//
//  Created by Kanyanat Meejareon on 9/10/2563 BE.
//

import Foundation

class ParkingLocation: Codable{
    
    var id: String?
    var name: String?
    var address: String?
    var mobilitySpaces: Int?
    var type: String?
    var latitude: Float?
    var longitude: Float?

}
