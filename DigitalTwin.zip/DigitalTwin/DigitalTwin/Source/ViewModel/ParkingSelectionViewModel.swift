//
//  ParkingSelectionViewController.swift
//  DigitalTwin
//
//  Created by Kanyanat Meejareon on 5/10/2563 BE.
//

import Foundation

class ParkingSelectionViewModel{
    
    var parkingLocationList: [ParkingLocation] = []
   
}
