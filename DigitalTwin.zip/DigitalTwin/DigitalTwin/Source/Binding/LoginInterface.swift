//
//  LoginInterface.swift
//  DigitalTwin
//
//  Created by Kanyanat Meejareon on 1/10/2563 BE.
//

import Foundation

// MARk - Data-binding
protocol LoginViewModelDelegate: class {
    func showMessageAlert(message: String)
    func showMainpage()
}

